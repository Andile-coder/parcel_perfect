const { getPlacesByPostcodeAsync } = require("@thinwood/parcelperfect/src/places");
const lobster = require("./lobster");

const fetchDestination = async (order, token) => {
    const postcode = order.billing.postcode;
    const city = order.billing.city;

    const result = await getPlacesByPostcodeAsync(postcode, token);
    if (result.errorcode) {
        lobster.error("fetchDestination", result.errormessage);
        throw Error;
    } else {
        const places = result.results;
        lobster.info("CITY", city);
        lobster.info("AVAILABLE PLACES", places);
        const filteredPlaces = places.filter(x => x.town.toLowerCase().includes(city.toLowerCase()));
        lobster.info("FILTERED", filteredPlaces);
        if (filteredPlaces.length) {
            const destination = filteredPlaces[0];
            return destination;
        } else {
            return null;
        }
    }
}

module.exports = fetchDestination;

