const fetchOrigin = require("./fetchOrigin");
const { requestQuote } = require("@thinwood/parcelperfect/src/quotes");
const lobster = require("./lobster");

const generateQuote = (destination, origin, order) => {
    console.log(order);

    return {
        // quoteno: "",
        // waybill: "",
        details: {
            specinstruction: order.notes,
            reference: order.number,

            origperadd1: "102 Lilian Ngoyi Road",
            origperadd2: "102 Lilian Ngoyi Road",
            origperadd3: "102 Lilian Ngoyi Road",
            origperadd4: "102 Lilian Ngoyi Road",
            origperphone:"012345678",
            origpercell:"012345678",
            origplace: origin.place,
            origtown: origin.town,
            origpers: "MINT MARKETING T/A MUSE BEAUTY",
            origpercontact: "TASNEEM",
            origperpcode: origin.pcode,

            /* LOGICAL SPLIT */
            destperadd1: order.billing.address_1,
            destperadd2: order.billing.address_1,
            destperadd3: order.billing.address_1,
            destperadd4: order.billing.address_1,
            destperphone: order.billing.phone,
            destpercell: order.billing.phone,
            destplace: destination.place,
            desttown: destination.town,
            destpers: order.billing.first_name + order.billing.last_name,
            destpercontact: order.billing.first_name,
            destperpcode: destination.pcode,
        },
        contents: [
            {
                item: 1,
                desc: "Test",
                pieces: 1,
                dim1: 1,
                dim2: 1,
                dim3: 1,
                actmass: 1,
            },    
        ],
        ttype: "I"    
    };
}

const createQuote = async (order, destination, token) => {
    const origin = await fetchOrigin(token);
    if (!origin) throw Error;

    const quote = generateQuote(destination, origin, order);

    console.log(quote);

    const response = await requestQuote(quote, token);
    if (response.errorcode) {
        lobster.error("createQuote", response.errormessage);
        throw Error(response.errormessage);
    } else {
        return response.results[0];
    }
}

module.exports = createQuote;