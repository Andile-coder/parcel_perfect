const sendgrid = require("@sendgrid/mail");
const functions = require("firebase-functions");
const Order = require("./models/order");

if (process.env.environment === "development") {
    sendgrid.setApiKey(process.env.sendgrid_key);
} else {
    sendgrid.setApiKey(functions.config().sendgrid.key);
}

const send = async (order) => {
    const mail = {
        from: "sales@musebeauty.co.za",
        personalizations: [
            {
                to: [
                    {
                        email: order.email
                    }
                ],
                dynamic_template_data: {
                    receiver_name: order.name,
                    waybill_number: order.waybillno,
                    tracking_code: `http://tracking.pperfect.com/waybill.php?ppcust=2500.2401.3136&waybill=${order.waybillno}`,
                    address_1: order.address.address_1,
                    address_2: order.address.address_2,
                    city: order.address.city,
                    order_number: order.number
                }
            }
        ],
        template_id: "d-3975c310a9f24347ae17a09515e31a4e"
    }
    return await sendgrid.send(mail);
}

module.exports = { send };