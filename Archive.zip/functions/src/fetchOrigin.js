const functions = require("firebase-functions");
const { getPlacesByPostcodeAsync } = require("@thinwood/parcelperfect/src/places");
const lobster = require("./lobster");

const fetchOrigin = async (token) => {
    let originPostalcode;
    let originCity;
    if (process.env.environment === "development") {
        originPostalcode = process.env.origin_postcode;
        originCity = process.env.origin_city;
    } else {
        originPostalcode = functions.config().origin.postcode;
        originCity = functions.config().origin.city;
    }


    const result = await getPlacesByPostcodeAsync(originPostalcode, token);

    if (result.errorcode) {
        lobster.error("fetchOrigin", result.errormessage);
        throw Error;
    } else {
        const places = result.results;
        const filteredPlaces = places.filter(x => x.town.toLowerCase() === originCity.toLowerCase());
        if (filteredPlaces.length) {
            const origin = filteredPlaces[0];
            return origin;
        } else {
            return null;
        }
    }
}

module.exports = fetchOrigin;

