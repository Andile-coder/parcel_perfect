const express = require("express");
const cors = require("cors");
const { authenticateAsync } = require("@thinwood/parcelperfect/src/authentication");
const fetchDestination = require("./src/fetchDestination");
const createQuote = require("./src/createQuote");
const { updateService, quoteToCollection } = require("@thinwood/parcelperfect/src/quotes");

const Order = require("./src/models/order");
const lobster = require("./src/lobster");
const { fetchOrder } = require("./fetchOrder");
const { send } = require("./src/sendgrid");

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (request, response) => {
    console.info("👋 Hello from mock server!");
    response.send("👋 Hello from mock server!");
});

app.post("/order", async (request, response) => {
    const wcorder = request.body;
    const order = new Order(
        wcorder.id, 
        wcorder.number, 
        `${wcorder.billing.first_name} ${wcorder.billing.last_name}`, 
        wcorder.billing.email, 
        wcorder.billing.phone,
        {
            address_1: wcorder.billing.address_1,
            address_2: wcorder.billing.address_2,
            city: wcorder.billing.city,
            state: wcorder.billing.state,
            country: wcorder.billing.country,
            postcode: wcorder.billing.postcode
        },
        wcorder.customer_note
    );
    order.save();

    try {
        const username = process.env.parcelperfect_username;
        const password = process.env.parcelperfect_password;
        const token = await authenticateAsync(username, password);
        const destination = await fetchDestination(wcorder, token);

        console.log(token);
        console.log(destination , {a: 's'});
        // response.status(200).json(destination);

        if (destination) {
            const quote = await createQuote(wcorder, destination, token);                      

            order.quoteno = quote.quoteno;
            order.update();

            const service = await updateService(quote.quoteno, "ONX", token);
            if (service.errorcode) throw Error(service.errormessage);

            const collection = await quoteToCollection(quote.quoteno, token);
            if (collection.errorcode) throw Error(collection.errormessage);

            order.waybillno = collection.results[0].waybillno;
            order.update();

            response.json(order);
        } else {
            // response.status(404).json();
        }
    } catch (error) {
        lobster.error(error);
        response.status(500).send(error);
    }
});

app.put("/order", async (request, response) => {
    const wcorder = request.body;
    if (wcorder.status === "completed") {
        const order = await fetchOrder(wcorder.number);
        const result = await send(order);
        response.send(result);
    }
    response.send();
});

const startDevServer = () => {
    app.listen(3000, console.info("⚡ Listening on http://localhost:3000"));
}

module.exports = startDevServer;